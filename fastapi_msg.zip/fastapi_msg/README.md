#Introduction
This document describes the project organization

##Details
This is a message creating app with an ID
1. PostgreSQL for the database operations
2. Python for creating RESTful API  routes and for interacting with database layers

##To build and run all docker-compose files
docker-compose up --build

# core 
It contains the source code 
# config
It contains dependencies of source code
# Build 
It contains the build related things