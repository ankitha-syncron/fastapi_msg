import os
import app as app
from fastapi import FastAPI

from core.routers import message

app = FastAPI()

app.include_router(message.router)
