from fastapi import APIRouter, HTTPException, Depends
from typing import List
from core.services import message
from core.models import message_base
from sqlalchemy.orm import Session
from core.controller.database_handler import SessionLocal
from pydantic import constr


router = APIRouter()


# Dependency
def get_db():
    global db
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()


@router.post("/messages/{m_id}", response_model=message_base.message_base)
def create_message(message_obj: message_base.message_base, m_id: int, db: Session = Depends(get_db)):
    message_obj.id = m_id
    result = message.get_message(db, m_id=message_obj.id)
    if result:
        raise HTTPException(status_code=409, detail="id already there")
    result = message.create_message(db, message_obj)
    return result


@router.post("/messages", response_model=message_base.message_base)
def create_message(messages: constr(regex="^[a-zA-z\\s]*$"), m_id: int, db: Session = Depends(get_db)):
    message_obj = message_base.message_base(id=m_id, text=messages)
    result = message.get_message(db, m_id=m_id)
    if result:
        raise HTTPException(status_code=409, detail="id already there")
    result = message.create_message(db, message_obj)
    return result


@router.get("/messages/", response_model=List[message_base.message_base])
def read_messages(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    messages = message.get_messages(db, skip=skip, limit=limit)
    return messages


@router.get("/messages/{m_id}", response_model=message_base.message_base)
def read_message(m_id: int, db: Session = Depends(get_db)):
    result = message.get_message(db, m_id=m_id)
    if result is None:
        raise HTTPException(status_code=404, detail="id not found")
    return result
