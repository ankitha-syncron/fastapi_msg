from core.models import message_base, message_table
from core.repository import message
from sqlalchemy.orm import Session


def get_message(db: Session, m_id: int):
    return message.get_message(db, m_id)


def get_messages(db: Session, skip: int = 0, limit: int = 100):
    return message.get_messages(db, skip, limit)


def create_message(db: Session, message_obj: message_base.message_base):
    return message.create_message(message_obj)


def update_message(db, Message_obj, none=None):
    return none
