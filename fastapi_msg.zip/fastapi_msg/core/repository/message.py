from core.models import message_base, message_table
from sqlalchemy.orm import Session
from core.controller.database_handler import engine
import sys


if "pytest" not in sys.modules:
    message_table.Base.metadata.create_all(bind=engine)


def get_message(db: Session, m_id: int):
    return db.query(message_table.message).filter(message_table.message.id == m_id).first()


def get_messages(db: Session, skip: int = 0, limit: int = 100):
    return db.query(message_table.message).offset(skip).limit(limit).all()


def create_message(db: Session, message: message_base.message_base):
    db_user = message_table.message(id=message.id, text=message.text)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user
