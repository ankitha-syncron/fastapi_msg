from pydantic import BaseModel


class message_base(BaseModel):

    def __init__(self, *args, **kwargs):
        super().__init__()
        self.id = None

    title: str
    date: str
    text: str
    user_id: str
    color: str

    class Config:
        orm_mode = True
