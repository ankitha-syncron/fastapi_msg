# import SQLALCHEMY as SQLALCHEMY
from sqlalchemy import create_engine
from sqlalchemy.dialects.postgresql import psycopg2
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from pathlib import Path
from dotenv import load_dotenv
import os

# env_path = Path.cwd()/'..'/'..'/'config'/'.env'
from core.main import app

env_path = Path('/code/config/.env')
load_dotenv(dotenv_path=env_path)
Postgres_user = os.getenv("POSTGRES_USER")
Postgres_password = os.getenv("POSTGRES_PASSWORD")
Postgres_db = os.getenv("POSTGRES_DB")
host = os.getenv("host")

pg_user = "postgres"
pg_pwd = "ankithahm"
pg_port = "5432"
#app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://{postgres}:{ankithahm}@localhost:{5432}/postgres".format(username=pg_user, password=pg_pwd, port=pg_port)

cred = f"{Postgres_user}:{Postgres_password}@{host}/{Postgres_db}"
SQLALCHEMY_DATABASE_URL = f"postgresql://{cred}"

engine = create_engine('postgresql+psycopg2://postgres:ankithahm@localhost/postgres')
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
